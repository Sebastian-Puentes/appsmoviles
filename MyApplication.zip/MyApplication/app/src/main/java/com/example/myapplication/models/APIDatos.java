package com.example.myapplication.models;

public class APIDatos {
    private int Numero;
    private int Cuadrado;
    private int Cubo;
    private float Raiz_cuadrada;
    private float Raiz_cubica;

    public int getNumero() {
        return Numero;
    }

    public void setNumero(int numero) {
        Numero = numero;
    }

    public int getCuadrado() {
        return Cuadrado;
    }

    public void setCuadrado(int cuadrado) {
        Cuadrado = cuadrado;
    }

    public int getCubo() {
        return Cubo;
    }

    public void setCubo(int cubo) {
        Cubo = cubo;
    }

    public float getRaiz_cuadrada() {
        return Raiz_cuadrada;
    }

    public void setRaiz_cuadrada(float raiz_cuadrada) {
        Raiz_cuadrada = raiz_cuadrada;
    }

    public float getRaiz_cubica() {
        return Raiz_cubica;
    }

    public void setRaiz_cubica(float raiz_cubica) {
        Raiz_cubica = raiz_cubica;
    }
}
