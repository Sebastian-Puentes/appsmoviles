package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.interfaces.NumerosAPI;
import com.example.myapplication.models.APIDatos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class MainActivity extends AppCompatActivity {
    TextView t1, t2, t3, t4;
    Button mos;
    EditText e1;
    Connection connection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        t1 = findViewById(R.id.t1);
        t2 = findViewById(R.id.t2);
        t3 = findViewById(R.id.t3);
        t4 = findViewById(R.id.t4);
        e1 = findViewById(R.id.e1);
        mos = findViewById(R.id.mos);

        mos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                find(e1.getText().toString());
            }
        });
    }
        private void find(String codigo){
        Retrofit retrofit=new Retrofit.Builder().baseUrl("http://127.0.0.1/api/consulta.php?Numero=1")
                .addConverterFactory(GsonConverterFactory.create()).build();

            NumerosAPI numerosAPI=retrofit.create(NumerosAPI.class);
            Call<APIDatos> call=numerosAPI.find(codigo);
            call.enqueue(new Callback<APIDatos>() {
                @Override
                public void onResponse(Call<APIDatos> call, Response<APIDatos> response) {
                    try {

                        if (response.isSuccessful()){
                            APIDatos a=response.body();
                            t1.setText(a.getCuadrado());
                            t2.setText(a.getCubo());
                            t3.setText(String.valueOf(a.getRaiz_cuadrada()));
                            t4.setText(String.valueOf(a.getRaiz_cubica()));
                        }

                    }catch (Exception ex){
                        Toast.makeText(MainActivity.this, ex.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<APIDatos> call, Throwable t) {
                    Toast.makeText(MainActivity.this, "Eror de red", Toast.LENGTH_SHORT).show();
                }
            });
        }
}