package com.example.myapplication.interfaces;

import com.example.myapplication.models.APIDatos;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface NumerosAPI {
    @GET("xampp/api/consulta.php")
    public Call<APIDatos> find(@Query("Numero") String numero);

}
